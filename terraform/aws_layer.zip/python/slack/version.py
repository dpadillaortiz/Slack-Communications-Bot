from slack_sdk.version import __version__  # noqa
