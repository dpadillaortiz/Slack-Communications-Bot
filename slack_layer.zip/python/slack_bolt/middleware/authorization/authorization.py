from ..middleware import Middleware


class Authorization(Middleware):
    pass
